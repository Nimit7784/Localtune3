# LocalTune 2.0 — Android music player

LocalTune 2.0 upgrades the original native Android player with online discovery, timed lyrics, and a Media3 playback queue while retaining the on-device music library.

## Features in this build

- **Online discovery:** search the Audius public catalogue and stream tracks through its track-stream endpoint. Availability is limited to music in the Audius catalogue; this is not a commercial all-label catalogue.
- **Lyrics:** fetch plain or timestamped lyrics from LRCLIB. Timestamped LRC lines are highlighted against the current playback position.
- **Queue:** add tracks, play a queued item, inspect the active Media3 playlist, and remove queued items.
- **Local library:** scan Android MediaStore audio and search by title or artist.
- **Playback:** AndroidX Media3 ExoPlayer and MediaSessionService for background playback and system media controls.
- **Interface:** dark Apple Music-inspired layout with a red accent.

## Build from a phone with GitHub Actions

1. Create or open your GitHub repository named `LocalTune`.
2. Upload the **contents** of this ZIP to the repository root, including `.github` and `app`.
3. Open **Actions** and select **Build LocalTune APK**.
4. Run the workflow if it did not start automatically.
5. When it succeeds, open the run's **Artifacts** section and download `LocalTune-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk` on your Android device.

The workflow uses Java 17, Android SDK Platform 35, and Gradle 8.9. This archive does not include a prebuilt APK.

## Build locally

Open the project in Android Studio with Android SDK Platform 35 installed. Let Gradle sync, then run the `app` configuration or use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Services and responsible use

- Audius provides read-only discovery and streaming endpoints. Most read-only requests work without credentials; API keys can increase rate limits. Do not embed a private API secret in the APK.
- LRCLIB is a community lyrics service. Requests identify the client with `User-Agent`; clients should respect HTTP 429 and `Retry-After` responses. Lyrics may be unavailable or unsynchronized.
- Track availability, stream URLs, API limits, metadata quality, and rights vary by provider and track. The app does not bypass paywalls or DRM.

## Current scope and known limitations

- The queue is held by the active Media3 player session; it is not yet persisted across a force-stop/reboot.
- The device library is read from MediaStore; favorites, custom playlists, Room persistence, album artwork caching, and playlist import are not part of this first 2.0 upgrade.
- Audius is the first online provider adapter. A second provider can be added behind the same repository boundary.
- This source archive has not been compiled in this environment because Gradle and the Android SDK are unavailable here. Use the included GitHub Actions workflow to obtain the authoritative compile result before installing.

## Project details

- Application ID: `com.example.localtune`
- Version: `2.0` (versionCode 3)
- Minimum Android API: 23
- Compile / target SDK: 35
- Kotlin + Jetpack Compose + AndroidX Media3
