package com.example.localtune

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

/** Read-only Audius catalogue adapter. No API secret is embedded in the APK. */
class AudiusRepository {
    private val baseUrl = "https://api.audius.co/v1"
    private val appName = "LocalTune"

    fun search(query: String): List<MusicTrack> {
        require(query.isNotBlank()) { "Enter a song, artist or keyword." }
        val encoded = URLEncoder.encode(query.trim(), "UTF-8")
        val json = getJson("$baseUrl/tracks/search?query=$encoded&limit=25&app_name=$appName")
        val data = json.optJSONArray("data") ?: return emptyList()
        return buildList {
            for (i in 0 until data.length()) {
                val item = data.optJSONObject(i) ?: continue
                val id = item.optString("id").takeIf { it.isNotBlank() } ?: continue
                val title = item.optString("title", "Untitled")
                val user = item.optJSONObject("user")
                val artist = user?.optString("name")?.takeIf { !it.isNullOrBlank() } ?: "Unknown artist"
                val artwork = item.optJSONObject("artwork")
                val art = artwork?.optString("150x150")?.takeIf { it.startsWith("https://") }
                val duration = item.optLong("duration", 0L).coerceAtLeast(0L) * 1000L
                add(
                    MusicTrack(
                        id = "audius:$id",
                        title = title,
                        artist = artist,
                        album = "",
                        durationMs = duration,
                        artworkUrl = art,
                        streamUrl = "$baseUrl/tracks/$id/stream?app_name=$appName",
                        source = TrackSource.AUDIUS
                    )
                )
            }
        }
    }

    private fun getJson(address: String): JSONObject {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12_000
            readTimeout = 18_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "LocalTune/2.0 Android")
        }
        try {
            val status = connection.responseCode
            val body = (if (status in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status !in 200..299) throw IllegalStateException("Audius request failed (HTTP $status).")
            return JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }
}
