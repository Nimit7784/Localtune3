package com.example.localtune

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.regex.Pattern

class LyricsRepository {
    fun findLyrics(track: MusicTrack): Pair<String, List<LyricLine>> {
        val title = URLEncoder.encode(track.title, "UTF-8")
        val artist = URLEncoder.encode(track.artist, "UTF-8")
        val album = track.album.takeIf { it.isNotBlank() }?.let { "&album_name=${URLEncoder.encode(it, "UTF-8")}" }.orEmpty()
        val duration = if (track.durationMs > 0) "&duration=${track.durationMs / 1000}" else ""
        val address = "https://lrclib.net/api/get?track_name=$title&artist_name=$artist$album$duration"
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 15_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "LocalTune/2.0 (Android music player)")
        }
        try {
            val status = connection.responseCode
            if (status == 404) return "No lyrics found for this track." to emptyList()
            if (status == 429) return "Lyrics service rate limit reached. Try again later." to emptyList()
            if (status !in 200..299) return "Lyrics service unavailable (HTTP $status)." to emptyList()
            val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            val synced = json.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
            val plain = json.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
            if (synced != null) return synced to parseLrc(synced)
            return (plain ?: "Instrumental track or lyrics unavailable.") to emptyList()
        } catch (e: Exception) {
            return "Could not load lyrics: ${e.message ?: "network error"}" to emptyList()
        } finally {
            connection.disconnect()
        }
    }

    private fun parseLrc(raw: String): List<LyricLine> {
        val pattern = Pattern.compile("\\[(\\d{2}):(\\d{2})(?:\\.(\\d{1,3}))?]\\s*(.*)")
        return raw.lineSequence().mapNotNull { line ->
            val matcher = pattern.matcher(line.trim())
            if (!matcher.matches()) return@mapNotNull null
            val minutes = matcher.group(1)?.toLongOrNull() ?: 0L
            val seconds = matcher.group(2)?.toLongOrNull() ?: 0L
            val fraction = matcher.group(3).orEmpty().padEnd(3, '0').take(3).toLongOrNull() ?: 0L
            LyricLine((minutes * 60 + seconds) * 1000 + fraction, matcher.group(4).orEmpty())
        }.sortedBy { it.timeMs }.toList()
    }
}
