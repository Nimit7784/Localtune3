package com.example.localtune

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executor

private val Ink = Color(0xFF101010)
private val Panel = Color(0xFF202020)
private val Accent = Color(0xFFFA243C)
private val Muted = Color(0xFFA6A6A6)

private data class LocalAudio(val id: Long, val title: String, val artist: String, val uri: Uri, val durationMs: Long)
private enum class AppTab { HOME, ONLINE, LIBRARY, QUEUE, LYRICS }

class MainActivity : ComponentActivity() {
    private var controller: MediaController? by mutableStateOf(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val mainExecutor: Executor by lazy { ContextCompat.getMainExecutor(this) }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, android.content.ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try { controller = controllerFuture?.get() } catch (_: Exception) { controller = null }
        }, mainExecutor)
    }

    override fun onStop() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        controller = null
        super.onStop()
    }

    private fun audioPermission(): String = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPermission() = ContextCompat.checkSelfPermission(this, audioPermission()) == PackageManager.PERMISSION_GRANTED

    private fun loadLocalTracks(): List<LocalAudio> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
        val result = mutableListOf<LocalAudio>()
        contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                result += LocalAudio(id, cursor.getString(titleCol) ?: "Unknown title",
                    cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist",
                    ContentUris.withAppendedId(collection, id), cursor.getLong(durationCol))
            }
        }
        return result
    }

    private fun LocalAudio.asMusicTrack() = MusicTrack(
        id = "local:$id", title = title, artist = artist, durationMs = durationMs,
        streamUrl = uri.toString(), source = TrackSource.LOCAL
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var tab by remember { mutableStateOf(AppTab.HOME) }
            var localTracks by remember { mutableStateOf(emptyList<LocalAudio>()) }
            var onlineTracks by remember { mutableStateOf(emptyList<MusicTrack>()) }
            var searchText by remember { mutableStateOf("") }
            var loading by remember { mutableStateOf(false) }
            var message by remember { mutableStateOf("") }
            var lyricsText by remember { mutableStateOf("Select a playing track and load its lyrics.") }
            var lyricLines by remember { mutableStateOf(emptyList<LyricLine>()) }
            var position by remember { mutableLongStateOf(0L) }
            var duration by remember { mutableLongStateOf(0L) }
            var isPlaying by remember { mutableStateOf(false) }
            var currentTitle by remember { mutableStateOf("Choose a track") }
            var currentArtist by remember { mutableStateOf("LocalTune") }
            var refreshKey by remember { mutableIntStateOf(0) }
            val scope = rememberCoroutineScope()
            val audius = remember { AudiusRepository() }
            val lyrics = remember { LyricsRepository() }
            val c = controller

            val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
                if (granted) localTracks = loadLocalTracks() else message = "Audio permission is required to scan device music."
            }

            fun scanLibrary() {
                if (hasAudioPermission()) localTracks = loadLocalTracks()
                else permissionLauncher.launch(audioPermission())
            }

            fun playTrack(track: MusicTrack) {
                val player = controller ?: run { message = "Playback service is still starting. Try again."; return }
                player.setMediaItem(track.toMediaItem())
                player.prepare()
                player.play()
                currentTitle = track.title
                currentArtist = track.artist
            }

            fun addToQueue(track: MusicTrack) {
                val player = controller ?: return
                val wasEmpty = player.mediaItemCount == 0
                player.addMediaItem(track.toMediaItem())
                message = "Added to queue: ${track.title}"
                if (wasEmpty) { player.prepare(); player.play() }
            }

            DisposableEffect(c) {
                val listener = object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        currentTitle = mediaItem?.mediaMetadata?.title?.toString() ?: "Choose a track"
                        currentArtist = mediaItem?.mediaMetadata?.artist?.toString() ?: "LocalTune"
                        lyricLines = emptyList()
                        lyricsText = "Lyrics not loaded. Open Lyrics to fetch them."
                    }
                    override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
                }
                c?.addListener(listener)
                onDispose { c?.removeListener(listener) }
            }

            LaunchedEffect(c, refreshKey) {
                while (c != null) {
                    position = c.currentPosition.coerceAtLeast(0L)
                    duration = c.duration.coerceAtLeast(0L)
                    isPlaying = c.isPlaying
                    c.currentMediaItem?.let { item ->
                        currentTitle = item.mediaMetadata.title?.toString() ?: currentTitle
                        currentArtist = item.mediaMetadata.artist?.toString() ?: currentArtist
                    }
                    kotlinx.coroutines.delay(400)
                }
            }

            MaterialTheme(colorScheme = darkColorScheme(
                background = Ink, surface = Panel, primary = Accent,
                onBackground = Color.White, onSurface = Color.White
            )) {
                Column(Modifier.fillMaxSize().background(Ink).statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(top = 17.dp, bottom = 14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("LOCALTUNE", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text(when (tab) {
                                AppTab.ONLINE -> "Discover music"
                                AppTab.LIBRARY -> "Your library"
                                AppTab.QUEUE -> "Up next"
                                AppTab.LYRICS -> "Lyrics"
                                else -> "Music, uninterrupted."
                            }, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        }
                        if (tab == AppTab.LIBRARY) TextButton(onClick = { scanLibrary() }) { Text("SCAN", color = Accent) }
                    }

                    if (tab == AppTab.ONLINE || tab == AppTab.LIBRARY) {
                        OutlinedTextField(
                            value = searchText, onValueChange = { searchText = it }, modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text(if (tab == AppTab.ONLINE) "Search Audius tracks and artists" else "Search songs or artists", color = Muted) },
                            singleLine = true, shape = RoundedCornerShape(15.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF383838), focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Accent)
                        )
                        if (tab == AppTab.ONLINE) {
                            Button(onClick = {
                                if (searchText.isBlank()) { message = "Enter a search term." }
                                else scope.launch {
                                    loading = true; message = ""
                                    try { onlineTracks = withContext(Dispatchers.IO) { audius.search(searchText) }; if (onlineTracks.isEmpty()) message = "No Audius tracks found." }
                                    catch (e: Exception) { message = e.message ?: "Online search failed." }
                                    finally { loading = false }
                                }
                            }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                                Text(if (loading) "SEARCHING…" else "SEARCH ONLINE")
                            }
                        }
                    }

                    if (message.isNotBlank()) Text(message, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 7.dp))

                    when (tab) {
                        AppTab.ONLINE -> {
                            Text("AUDIOUS CATALOGUE", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(vertical = 10.dp))
                            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
                                items(onlineTracks, key = { it.id }) { track -> TrackRow(track.title, track.artist, onPlay = { playTrack(track) }, onAdd = { addToQueue(track) }) }
                            }
                        }
                        AppTab.LIBRARY -> {
                            Text("ON THIS DEVICE · ${localTracks.size} TRACKS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(vertical = 10.dp))
                            val filtered = localTracks.filter { it.title.contains(searchText, true) || it.artist.contains(searchText, true) }
                            if (localTracks.isEmpty()) {
                                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("♪", color = Accent, fontSize = 52.sp)
                                        Text("Your library is empty", color = Color.White, fontWeight = FontWeight.SemiBold)
                                        Text("Scan your device for local audio.", color = Muted, fontSize = 12.sp)
                                        Button(onClick = { scanLibrary() }, colors = ButtonDefaults.buttonColors(containerColor = Accent), modifier = Modifier.padding(top = 12.dp)) { Text("SCAN DEVICE") }
                                    }
                                }
                            } else LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
                                items(filtered, key = { it.id }) { track -> TrackRow(track.title, track.artist, onPlay = { playTrack(track.asMusicTrack()) }, onAdd = { addToQueue(track.asMusicTrack()) }) }
                            }
                        }
                        AppTab.QUEUE -> {
                            val player = c
                            Text("${player?.mediaItemCount ?: 0} TRACKS IN QUEUE", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(vertical = 10.dp))
                            LazyColumn(Modifier.weight(1f)) {
                                if (player != null) items(player.mediaItemCount) { index ->
                                    val item = player.getMediaItemAt(index)
                                    TrackRow(item.mediaMetadata.title?.toString() ?: "Unknown track", item.mediaMetadata.artist?.toString() ?: "Unknown artist",
                                        onPlay = { player.seekTo(index, 0L); player.play() }, onAdd = { player.removeMediaItem(index) }, actionLabel = "REMOVE")
                                }
                            }
                        }
                        AppTab.LYRICS -> {
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(currentTitle, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(currentArtist, color = Muted, fontSize = 12.sp)
                                }
                                Button(onClick = {
                                    val item = c?.currentMediaItem
                                    if (item == null) message = "Play a track first."
                                    else scope.launch {
                                        loading = true
                                        val track = MusicTrack(item.mediaId, item.mediaMetadata.title?.toString() ?: currentTitle,
                                            item.mediaMetadata.artist?.toString() ?: currentArtist,
                                            item.mediaMetadata.albumTitle?.toString().orEmpty(), c?.duration?.coerceAtLeast(0L) ?: 0L,
                                            streamUrl = item.localConfiguration?.uri?.toString() ?: "", source = TrackSource.AUDIUS)
                                        val result = withContext(Dispatchers.IO) { lyrics.findLyrics(track) }
                                        lyricsText = result.first; lyricLines = result.second; loading = false
                                    }
                                }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text(if (loading) "LOADING" else "FETCH LYRICS") }
                            }
                            if (lyricLines.isNotEmpty()) {
                                val activeIndex = lyricLines.indexOfLast { it.timeMs <= position }.coerceAtLeast(0)
                                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 24.dp)) {
                                    items(lyricLines.size) { index ->
                                        Text(lyricLines[index].text, color = if (index == activeIndex) Color.White else Muted,
                                            fontSize = if (index == activeIndex) 21.sp else 16.sp,
                                            fontWeight = if (index == activeIndex) FontWeight.Bold else FontWeight.Normal,
                                            modifier = Modifier.fillMaxWidth().padding(vertical = 11.dp))
                                    }
                                }
                            } else Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Text(lyricsText, color = Muted, fontSize = 14.sp)
                            }
                        }
                        AppTab.HOME -> {
                            Text("YOUR MUSIC", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(vertical = 10.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                HomeTile("Discover", "Search online music", Modifier.weight(1f)) { tab = AppTab.ONLINE }
                                HomeTile("Library", "Songs on device", Modifier.weight(1f)) { tab = AppTab.LIBRARY }
                            }
                            Spacer(Modifier.height(14.dp))
                            Text("PLAYBACK", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                            Text("Online catalogue powered by Audius. Lyrics powered by LRCLIB.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                            Spacer(Modifier.weight(1f))
                        }
                    }

                    if (tab != AppTab.LYRICS) {
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)).background(Panel).padding(horizontal = 14.dp, vertical = 10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(currentTitle, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(currentArtist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                TextButton(onClick = { tab = AppTab.LYRICS }) { Text("LYRICS", color = Accent, fontSize = 10.sp) }
                                TextButton(onClick = { tab = AppTab.QUEUE }) { Text("QUEUE", color = Accent, fontSize = 10.sp) }
                                TextButton(onClick = { if (isPlaying) c?.pause() else c?.play() }) { Text(if (isPlaying) "Ⅱ" else "▶", color = Color.White, fontSize = 18.sp) }
                            }
                            Slider(value = if (duration > 0) position.coerceAtMost(duration).toFloat() / duration else 0f,
                                onValueChange = { position = (it * duration).toLong() }, onValueChangeFinished = { c?.seekTo(position) },
                                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(formatTime(position), color = Muted, fontSize = 9.sp)
                                Text(formatTime(duration), color = Muted, fontSize = 9.sp)
                            }
                        }
                    }

                    Row(Modifier.fillMaxWidth().padding(top = 7.dp, bottom = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        NavItem("Home", tab == AppTab.HOME) { tab = AppTab.HOME }
                        NavItem("Online", tab == AppTab.ONLINE) { tab = AppTab.ONLINE }
                        NavItem("Library", tab == AppTab.LIBRARY) { tab = AppTab.LIBRARY }
                        NavItem("Queue", tab == AppTab.QUEUE) { tab = AppTab.QUEUE }
                    }
                }
            }
        }
    }

    private fun formatTime(ms: Long): String {
        val seconds = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(seconds / 60, seconds % 60)
    }
}

@Composable
private fun TrackRow(title: String, artist: String, onPlay: () -> Unit, onAdd: () -> Unit, actionLabel: String = "＋") {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).clickable(onClick = onPlay).padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(43.dp).clip(RoundedCornerShape(11.dp)).background(Color(0xFF32191D)), contentAlignment = Alignment.Center) {
            Text("♪", color = Accent, fontSize = 23.sp)
        }
        Column(Modifier.weight(1f).padding(start = 11.dp, end = 5.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(artist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        TextButton(onClick = onAdd) { Text(actionLabel, color = Accent, fontSize = 12.sp) }
    }
}

@Composable
private fun HomeTile(title: String, subtitle: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(Panel).clickable(onClick = onClick).padding(15.dp)) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(subtitle, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp))
    }
}

@Composable
private fun NavItem(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(label, color = if (selected) Accent else Muted, fontSize = 11.sp,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 9.dp, vertical = 9.dp))
}
